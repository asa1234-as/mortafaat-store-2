/**
 * Lightweight Supabase REST/Auth adapter.
 * No service-role key is ever used in the browser. Only the publishable/anon key belongs here.
 */
const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL as string | undefined;
const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY as string | undefined;
const SESSION_KEY = 'mortafaat_supabase_session';

export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

export type SupabaseSession = {
  access_token: string;
  refresh_token: string;
  expires_at?: number;
  user: { id: string; email?: string; phone?: string; user_metadata?: Record<string, unknown>; email_confirmed_at?: string | null };
};

function config() {
  if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ. أضف VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY إلى ملف البيئة.');
  return { url: SUPABASE_URL!.replace(/\/$/, ''), key: SUPABASE_ANON_KEY! };
}

export function getSupabaseSession(): SupabaseSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as SupabaseSession;
    if (session.expires_at && session.expires_at * 1000 < Date.now()) return null;
    return session;
  } catch { return null; }
}

function saveSession(session: SupabaseSession | null) {
  if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  else localStorage.removeItem(SESSION_KEY);
}

async function authRequest(path: string, body: unknown) {
  const { url, key } = config();
  const response = await fetch(`${url}/auth/v1/${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: key },
    body: JSON.stringify(body)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.msg || data.message || data.error_description || 'فشل التحقق من الحساب');
  return data;
}

export async function signInWithEmail(email: string, password: string) {
  const data = await authRequest('token?grant_type=password', { email, password });
  const session: SupabaseSession = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Math.floor(Date.now() / 1000) + Number(data.expires_in || 3600),
    user: data.user
  };
  saveSession(session);
  return session.user;
}

export async function signUpWithEmail(email: string, password: string, metadata: Record<string, unknown> = {}) {
  const data = await authRequest('signup', { email, password, data: metadata });
  if (data.access_token) {
    saveSession({
      access_token: data.access_token, refresh_token: data.refresh_token,
      expires_at: Math.floor(Date.now() / 1000) + Number(data.expires_in || 3600),
      user: data.user
    });
  }
  return data;
}

export async function signOutSupabase() {
  const session = getSupabaseSession();
  if (session && isSupabaseConfigured) {
    const { url, key } = config();
    await fetch(`${url}/auth/v1/logout`, {
      method: 'POST',
      headers: { apikey: key, Authorization: `Bearer ${session.access_token}` }
    }).catch(() => undefined);
  }
  saveSession(null);
}

export async function hasAdminRole(userId: string): Promise<boolean> {
  const session = getSupabaseSession();
  if (!session || !isSupabaseConfigured) return false;
  const { url, key } = config();
  const response = await fetch(`${url}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}&select=role`, {
    headers: { apikey: key, Authorization: `Bearer ${session.access_token}` }
  });
  if (!response.ok) return false;
  const rows = await response.json();
  return rows.some((row: { role: string }) => row.role === 'admin' || row.role === 'owner');
}

export async function signInAdmin(email: string, password: string) {
  const user = await signInWithEmail(email, password);
  const allowed = await hasAdminRole(user.id);
  if (!allowed) {
    await signOutSupabase();
    throw new Error('هذا الحساب غير مخوّل للوصول إلى لوحة الإدارة.');
  }
  return user;
}

export async function requestPasswordReset(email: string) {
  const { url, key } = config();
  const response = await fetch(`${url}/auth/v1/recover`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: key },
    body: JSON.stringify({ email })
  });
  if (!response.ok) throw new Error('تعذّر إرسال رابط استعادة كلمة المرور.');
}
