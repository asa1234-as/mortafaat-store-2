/**
 * Payment Gateway Adapter contract.
 * Implementations that contain provider secrets MUST live in Supabase Edge Functions,
 * not in this browser bundle. The browser only receives a checkout URL/reference.
 */
export type GatewayProvider = 'paymob' | 'kashier' | 'fawry' | 'custom';

export interface CreatePaymentRequest {
  orderId: string;
  amountMinor: number;
  currency: 'EGP';
  customer: { name: string; email?: string; phone: string };
  returnUrl: string;
}

export interface CreatePaymentResult {
  redirectUrl: string;
  providerReference: string;
}

export interface PaymentGatewayAdapter {
  readonly provider: GatewayProvider;
  createPayment(request: CreatePaymentRequest): Promise<CreatePaymentResult>;
}

/**
 * Payment status must only be changed by a verified provider webhook on the server.
 * Never accept a browser callback as proof of payment.
 */
export const PAYMENT_WEBHOOK_REQUIREMENTS = [
  'Verify provider signature/HMAC using a secret stored as an Edge Function secret',
  'Verify amount, currency, merchant account and provider transaction reference',
  'Make webhook handling idempotent',
  'Update payment_status to paid only after verified settlement/authorization',
  'Record gateway event and transaction id for audit'
] as const;
