# Mortafaat Store | مرتفعات ستور

React + TypeScript + Vite storefront with Arabic/English UI, PWA manifest, Supabase SQL foundation and Supabase email authentication.

Read **README_دليل_المشروع.md** for setup, Cloudflare Pages deployment, Supabase configuration, Android/iOS preparation, security notes and remaining launch requirements.

Important: the database schema and authentication foundation are included, but the storefront's product/order management has not yet been fully migrated from browser localStorage to Supabase. Do not use this build as a fully production-ready multi-device commerce system until the remaining integration checklist in the Arabic guide is completed.
