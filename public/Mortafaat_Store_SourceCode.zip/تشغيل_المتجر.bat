@echo off
chcp 65001 > nul
echo ========================================================
echo        جاري تشغيل مرتفعات ستور (Mortafaat Store)
echo ========================================================
echo.
cd /d "%~dp0"
if not exist node_modules (
  echo اول مرة: جاري تثبيت المكتبات (يحتاج انترنت، مرة واحدة فقط)...
  call npm.cmd install
)
echo فتح المتصفح على: http://localhost:3000
start http://localhost:3000
echo.
echo لتشغيل المتجر، يرجى عدم غلق هذه النافذة...
npm.cmd run dev
pause
