-- Mortafaat Store: Supabase schema (PostgreSQL)
-- Run once in Supabase SQL Editor using the project owner account.
create extension if not exists pgcrypto;

create type public.app_role as enum ('customer','admin','owner');
create type public.order_status as enum ('pending','processing','shipped','delivered','cancelled');
create type public.payment_status as enum ('unpaid','pending_verification','paid','failed','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.phone)
  on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create function public.prevent_self_role_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'Only an administrator may change account roles';
  end if;
  return new;
end; $$;
create trigger protect_profile_role before update on public.profiles
for each row execute procedure public.prevent_self_role_change();

create table public.categories (
  id text primary key,
  name_ar text not null,
  name_en text not null,
  icon text not null default 'Tag',
  image_url text,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique,
  name_ar text not null,
  name_en text not null default '',
  category_id text references public.categories(id) on delete set null,
  description text not null default '',
  price numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2) check (compare_at_price is null or compare_at_price >= price),
  stock_quantity int not null default 0 check (stock_quantity >= 0),
  images text[] not null default '{}',
  features jsonb not null default '[]'::jsonb,
  options jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  is_featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  recipient_name text not null,
  phone text not null,
  governorate text not null,
  city text,
  address_line text not null,
  notes text,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('percentage','fixed')),
  discount_value numeric(12,2) not null check (discount_value > 0),
  min_order_value numeric(12,2) not null default 0,
  max_uses int,
  uses_count int not null default 0,
  starts_at timestamptz,
  expires_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.store_settings (
  id int primary key default 1 check (id = 1),
  currency text not null default 'EGP',
  shipping_fee numeric(12,2) not null default 50,
  free_shipping_threshold numeric(12,2) not null default 1000,
  cod_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);
insert into public.store_settings(id) values (1) on conflict do nothing;

create table public.payment_gateways (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  display_name text not null,
  is_enabled boolean not null default false,
  public_config jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
-- Secret credentials belong in Supabase Edge Function secrets, never this table or the browser.

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity unique,
  user_id uuid not null references public.profiles(id),
  customer_name text not null,
  phone text not null,
  email text,
  governorate text not null,
  shipping_address text not null,
  notes text,
  subtotal numeric(12,2) not null check (subtotal >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  coupon_code text,
  shipping_fee numeric(12,2) not null check (shipping_fee >= 0),
  total numeric(12,2) not null check (total >= 0),
  payment_method text not null check (payment_method in ('cod','online')),
  payment_status public.payment_status not null default 'unpaid',
  gateway_provider text,
  gateway_transaction_id text,
  status public.order_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  sku text,
  unit_price numeric(12,2) not null check (unit_price >= 0),
  quantity int not null check (quantity > 0),
  selected_size text,
  selected_color text,
  line_total numeric(12,2) generated always as (unit_price * quantity) stored
);

create table public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.capture_admin_audit() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_id text;
begin
  if public.is_admin() then
    v_id := coalesce(to_jsonb(new)->>'id', to_jsonb(old)->>'id');
    insert into public.admin_audit_log(actor_id, action, entity_type, entity_id, details)
    values (
      auth.uid(), lower(TG_OP), TG_TABLE_NAME, v_id,
      jsonb_build_object(
        'before', case when TG_OP = 'INSERT' then null else to_jsonb(old) end,
        'after', case when TG_OP = 'DELETE' then null else to_jsonb(new) end
      )
    );
  end if;
  if TG_OP = 'DELETE' then return old; end if;
  return new;
end; $$;

create index products_category_idx on public.products(category_id);
create index products_active_idx on public.products(is_active);
create index orders_user_idx on public.orders(user_id, created_at desc);
create index orders_status_idx on public.orders(status, created_at desc);
create index order_items_order_idx on public.order_items(order_id);

create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role in ('admin','owner'));
$$;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.addresses enable row level security;
alter table public.coupons enable row level security;
alter table public.store_settings enable row level security;
alter table public.payment_gateways enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.admin_audit_log enable row level security;

create policy "profiles read self or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
create policy "profiles update self safe fields" on public.profiles for update to authenticated
using (id = auth.uid() or public.is_admin())
with check (id = auth.uid() or public.is_admin());
create policy "public read active categories" on public.categories for select to anon, authenticated using (is_active or public.is_admin());
create policy "admin manage categories" on public.categories for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public read active products" on public.products for select to anon, authenticated using (is_active or public.is_admin());
create policy "admin manage products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "customer manage own addresses" on public.addresses for all to authenticated
using (user_id = auth.uid() or public.is_admin()) with check (user_id = auth.uid() or public.is_admin());
create policy "admin manage coupons" on public.coupons for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public read store settings" on public.store_settings for select to anon, authenticated using (true);
create policy "admin update store settings" on public.store_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public read enabled payment methods" on public.payment_gateways for select to anon, authenticated using (is_enabled);
create policy "admin manage gateways" on public.payment_gateways for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "customer read own orders or admin" on public.orders for select to authenticated
using (user_id = auth.uid() or public.is_admin());
create policy "admin update orders" on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "customer read own order items or admin" on public.order_items for select to authenticated
using (exists(select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
create policy "admin manage order items" on public.order_items for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "admin audit read" on public.admin_audit_log for select to authenticated using (public.is_admin());
create policy "admin audit insert" on public.admin_audit_log for insert to authenticated with check (actor_id = auth.uid() and public.is_admin());

create trigger audit_products after insert or update or delete on public.products
for each row execute procedure public.capture_admin_audit();
create trigger audit_categories after insert or update or delete on public.categories
for each row execute procedure public.capture_admin_audit();
create trigger audit_coupons after insert or update or delete on public.coupons
for each row execute procedure public.capture_admin_audit();
create trigger audit_store_settings after insert or update or delete on public.store_settings
for each row execute procedure public.capture_admin_audit();
create trigger audit_orders after update on public.orders
for each row execute procedure public.capture_admin_audit();


-- Transactional COD order creation. Prices and stock are read from DB, never trusted from the browser.
create or replace function public.create_cod_order(
  p_customer_name text,
  p_phone text,
  p_governorate text,
  p_address text,
  p_notes text,
  p_items jsonb,
  p_coupon_code text default null
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_user uuid := auth.uid();
  v_order_id uuid;
  v_subtotal numeric(12,2) := 0;
  v_discount numeric(12,2) := 0;
  v_shipping numeric(12,2);
  v_total numeric(12,2);
  v_threshold numeric(12,2);
  v_coupon public.coupons%rowtype;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty int;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if coalesce(trim(p_customer_name),'') = '' or coalesce(trim(p_phone),'') = '' or
     coalesce(trim(p_governorate),'') = '' or coalesce(trim(p_address),'') = '' then
    raise exception 'Customer details are incomplete';
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Cart is empty';
  end if;

  -- Lock all referenced products to prevent overselling under concurrent orders.
  for v_item in
    select jsonb_build_object('product_id', product_id, 'quantity', sum(quantity))
    from (
      select (value->>'product_id')::uuid as product_id, (value->>'quantity')::int as quantity
      from jsonb_array_elements(p_items)
    ) grouped_items
    group by product_id
  loop
    v_qty := (v_item->>'quantity')::int;
    if v_qty < 1 or v_qty > 99 then raise exception 'Invalid quantity'; end if;
    select * into v_product from public.products
      where id = (v_item->>'product_id')::uuid and is_active = true for update;
    if not found then raise exception 'Product unavailable'; end if;
    if v_product.stock_quantity < v_qty then raise exception 'Insufficient stock for %', v_product.name_ar; end if;
    v_subtotal := v_subtotal + v_product.price * v_qty;
  end loop;

  select shipping_fee, free_shipping_threshold into v_shipping, v_threshold
  from public.store_settings where id = 1;
  if v_subtotal >= v_threshold then v_shipping := 0; end if;

  if p_coupon_code is not null and trim(p_coupon_code) <> '' then
    select * into v_coupon from public.coupons
    where upper(code) = upper(trim(p_coupon_code)) and is_active = true
      and (starts_at is null or starts_at <= now())
      and (expires_at is null or expires_at > now())
      and (max_uses is null or uses_count < max_uses)
    for update;
    if not found then raise exception 'Invalid or expired coupon'; end if;
    if v_subtotal < v_coupon.min_order_value then raise exception 'Minimum order value not reached'; end if;
    if v_coupon.discount_type = 'percentage' then
      v_discount := round(v_subtotal * v_coupon.discount_value / 100, 2);
    else
      v_discount := v_coupon.discount_value;
    end if;
    v_discount := least(v_discount, v_subtotal);
    update public.coupons set uses_count = uses_count + 1 where id = v_coupon.id;
  end if;

  v_total := greatest(0, v_subtotal - v_discount + v_shipping);
  insert into public.orders(user_id, customer_name, phone, email, governorate, shipping_address,
    notes, subtotal, discount_amount, coupon_code, shipping_fee, total, payment_method, payment_status)
  values (v_user, trim(p_customer_name), trim(p_phone),
    (select email from auth.users where id = v_user), trim(p_governorate), trim(p_address),
    nullif(trim(coalesce(p_notes,'')),''), v_subtotal, v_discount,
    case when p_coupon_code is null then null else upper(trim(p_coupon_code)) end,
    v_shipping, v_total, 'cod', 'unpaid')
  returning id into v_order_id;

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::int;
    select * into v_product from public.products where id = (v_item->>'product_id')::uuid for update;
    insert into public.order_items(order_id, product_id, product_name, sku, unit_price, quantity, selected_size, selected_color)
    values (v_order_id, v_product.id, v_product.name_ar, v_product.sku, v_product.price, v_qty,
      nullif(v_item->>'selected_size',''), nullif(v_item->>'selected_color',''));
    update public.products set stock_quantity = stock_quantity - v_qty,
      updated_at = now() where id = v_product.id;
  end loop;
  return v_order_id;
end; $$;
revoke all on function public.create_cod_order(text,text,text,text,text,jsonb,text) from public, anon;
grant execute on function public.create_cod_order(text,text,text,text,text,jsonb,text) to authenticated;

-- Promote the first owner manually after registering an account:
-- update public.profiles set role = 'owner' where id = (select id from auth.users where email = 'YOUR_EMAIL');
-- Never expose the Supabase service_role key in frontend code.

-- Realtime for admin order inbox.
alter publication supabase_realtime add table public.orders;

-- Create the public product image bucket. Uploads/deletes remain admin-only.
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "public read product images" on storage.objects for select
using (bucket_id = 'product-images');
create policy "admins upload product images" on storage.objects for insert to authenticated
with check (bucket_id = 'product-images' and public.is_admin());
create policy "admins update product images" on storage.objects for update to authenticated
using (bucket_id = 'product-images' and public.is_admin())
with check (bucket_id = 'product-images' and public.is_admin());
create policy "admins delete product images" on storage.objects for delete to authenticated
using (bucket_id = 'product-images' and public.is_admin());
