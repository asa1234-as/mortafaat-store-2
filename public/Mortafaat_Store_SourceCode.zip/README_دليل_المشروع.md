# مرتفعات ستور | Mortafaat Store

## الحالة الحالية
هذا المشروع نسخة React + TypeScript + Vite مع واجهة المتجر الأصلية وPWA. أضيفت إليه طبقة إعداد Supabase، ومخطط SQL آمن، ومصادقة فعلية بالبريد الإلكتروني، وتحقق دور المدير، وإزالة مسار الدخول الافتراضي 1234 والدفع الإلكتروني الوهمي.

**تنبيه إطلاق مهم:** لم يتم ربط مشروع Supabase خاص بك أو ترحيل واجهة المتجر بالكامل من التخزين المحلي إلى قاعدة البيانات بعد. لذلك لا تعتبر نسخة الإنتاج جاهزة لاستقبال طلبات حقيقية متعددة الأجهزة قبل إكمال قسم "ما يلزم قبل الإطلاق". إدارة المنتجات/الطلبات في الواجهة ما زالت تعتمد أجزاء منها على localStorage. قاعدة البيانات وRPC جاهزان كأساس خلفي، لكن يلزم إكمال ربط CRUD والطلب من الواجهة ثم اختبارها بحسابك.

## 1. المتطلبات
- Node.js 20 أو أحدث
- npm
- حساب مجاني Supabase
- حساب GitHub
- حساب Cloudflare

## 2. التشغيل المحلي
```bash
npm install
cp .env.example .env.local
npm run dev
```
افتح الرابط الذي يعرضه Vite (غالبًا `http://localhost:3000`).

## 3. إعداد Supabase
1. أنشئ مشروعًا جديدًا من https://supabase.com/dashboard.
2. افتح SQL Editor وشغّل محتويات `supabase/schema.sql`.
3. من Authentication > Providers فعّل Email، واضبط تأكيد البريد وإعدادات SMTP بما يناسبك. لا تعتمد على OTP مولّد داخل المتصفح.
4. من Project Settings > API انسخ Project URL و anon/publishable key فقط.
5. ضع القيم في `.env.local`:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. سجّل حساب المالك من واجهة المتجر، ثم نفّذ في SQL Editor (استبدل البريد):
```sql
update public.profiles
set role = 'owner'
where id = (select id from auth.users where email = 'YOUR_EMAIL');
```
7. أعد تشغيل Vite بعد تعديل متغيرات البيئة.

لا تضع `service_role` أو مفاتيح بوابات الدفع في متغيرات `VITE_` أو في ملفات المتصفح. خزّن الأسرار مستقبلًا في Supabase Edge Function Secrets فقط.

## 4. Cloudflare Pages مجانًا
1. ارفع المشروع إلى مستودع GitHub.
2. من Cloudflare Dashboard افتح Workers & Pages > Create > Pages > Connect to Git.
3. اختر المستودع والفرع.
4. إعدادات البناء:
   - Framework preset: Vite
   - Build command: `npm run build`
   - Build output directory: `dist`
5. أضف متغيري `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY` في إعدادات Environment Variables لبيئتي Production وPreview.
6. انشر المشروع. سيمنحك Cloudflare نطاقًا مجانيًا مثل `your-project.pages.dev`.
7. ملف `public/_redirects` يدعم توجيه SPA، و`public/_headers` يضيف ترويسات أمان أساسية.

الاستضافة المجانية تخضع لحدود وسياسات Cloudflare وSupabase وقد تتغير؛ لا يوجد ضمان "مجاني مدى الحياة".

## 5. GitHub
```bash
git init
git add .
git commit -m "Prepare Mortafaat Store"
git branch -M main
git remote add origin https://github.com/YOUR_USER/YOUR_REPOSITORY.git
git push -u origin main
```
لا ترفع `.env.local` أو أي مفاتيح سرية.

## 6. PWA وAndroid وiOS
المتجر يحتوي أصلًا على `public/manifest.json` ويعمل كـ PWA بعد نشره على HTTPS.
لتجهيز Capacitor بعد تثبيت الاعتماديات:
```bash
npm install @capacitor/core
npm install -D @capacitor/cli
npm install @capacitor/android @capacitor/ios
npx cap add android
npx cap add ios
npm run build
npx cap sync
npx cap open android
npx cap open ios
```
- Android: استخدم Android Studio لإنشاء APK/AAB وتوقيعه بمفتاح إصدار خاص.
- iOS: يتطلب macOS وXcode وحساب Apple Developer للنشر. لم يتم إنشاء أو توقيع تطبيق iOS في هذه البيئة.
- لم يتم إنشاء APK/AAB أو مشروع Xcode داخل هذه الحزمة؛ الأوامر أعلاه تنشئ المنصات محليًا بعد تثبيت الأدوات.

## 7. الدفع
الدفع عند الاستلام هو المسار المتاح في الواجهة. تم منع محاكاة نجاح الدفع الإلكتروني. ملف `src/lib/paymentGateway.ts` يحدد عقد Adapter فقط. لا توجد حاليًا تكاملات Paymob أو Kashier أو Fawry نشطة. يجب تنفيذ إنشاء جلسة الدفع والتحقق من Webhook داخل Supabase Edge Functions لكل مزود، وتخزين أسراره كـ Function Secrets. لا تحدّث الطلب إلى `paid` من المتصفح.

## 8. قاعدة البيانات والأمان
`supabase/schema.sql` ينشئ:
- profiles مع الأدوار customer/admin/owner
- products وcategories والمخزون
- addresses وcoupons وstore_settings
- payment_gateways
- orders وorder_items
- admin_audit_log
- سياسات RLS، مخزن صور عام للقراءة ورفع/حذف مقيد للمدير
- دالة `create_cod_order` تنشئ طلب COD وتتحقق من الأسعار والمخزون وتخصم الكميات داخل معاملة واحدة

لا تسمح للمستخدم بتغيير دوره؛ تمت إضافة trigger لمنع ترقية الذات. امنح دور owner يدويًا من SQL Editor لحساب موثوق فقط.

## 9. قائمة ما يلزم قبل الإطلاق التجاري
- [ ] إنشاء مشروع Supabase خاص بك وتشغيل SQL.
- [ ] إضافة بيانات المنتجات الفعلية إلى قاعدة البيانات.
- [ ] استكمال ربط واجهة المتجر وعمليات CRUD مع Supabase بدل localStorage.
- [ ] ربط Checkout بدالة `create_cod_order` وعرض الطلب الحقيقي في لوحة الإدارة.
- [ ] اختبار سياسات RLS بحساب عميل وحساب مدير منفصلين.
- [ ] إعداد سياسة الخصوصية والاسترجاع والشحن وبيانات التواصل القانونية.
- [ ] إعداد مزود بريد مناسب لتأكيد الحساب واستعادة كلمة المرور.
- [ ] بناء واختبار Android على Android Studio، وiOS على macOS/Xcode.
- [ ] قبل تفعيل بوابة دفع: تنفيذ Adapter الخادمي وWebhook موقّع واختبار sandbox الخاص بالمزود.

## 10. ملفات مهمة
- `supabase/schema.sql`: مخطط قاعدة البيانات والسياسات.
- `.env.example`: أسماء متغيرات البيئة دون أسرار.
- `src/lib/supabase.ts`: مصادقة Supabase عبر REST.
- `src/lib/paymentGateway.ts`: عقد تكامل بوابات الدفع.
- `capacitor.config.ts`: إعدادات Capacitor.
- `public/manifest.json`: إعداد PWA.
